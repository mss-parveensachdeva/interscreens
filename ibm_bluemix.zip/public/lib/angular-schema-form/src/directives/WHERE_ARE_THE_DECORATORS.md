Hi there,

as you probably have noticed the `decorators` folder and the bootstrap decorator has
been removed. This is intentional. Each decorator has it's own repo.

Material: https://github.com/Textalk/angular-schema-form-material
Bootstrap: https://github.com/Textalk/angular-schema-form-bootstrap
